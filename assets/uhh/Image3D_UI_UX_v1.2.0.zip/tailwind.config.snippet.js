module.exports = {
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0fdf9',
          100: '#ccf7e6',
          400: '#0ee0a6',
          600: '#00c37a',
        },
      },
      borderRadius: {
        '2xl': '1rem',
      },
      boxShadow: {
        card: '0 6px 18px rgba(2,8,23,0.35)',
        pop: '0 12px 30px rgba(2,8,23,0.45)',
      }
    }
  }
}
