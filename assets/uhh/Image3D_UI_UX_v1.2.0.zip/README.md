# Image3D UI/UX v1.2.0 Refresh Pack

This package contains a modernized UI/UX implementation for Image3D v1.2.0.

## Includes
- Design tokens (Tailwind-ready)
- Texture Slot Panel (HTML/CSS/TS)
- Export Modal (HTML/CSS/TS)
- UX & accessibility improvements
- Performance-friendly patterns

## How to use
1. Copy files into your Image3D project
2. Merge Tailwind config tokens if applicable
3. Import TS modules and bind to your MaterialManager / Exporters

Built for Image3D by Dan.
