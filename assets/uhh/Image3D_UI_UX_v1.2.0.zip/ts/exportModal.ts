export class ExportUI {
  constructor(private exporter:any){
    document.getElementById('start-export')?.addEventListener('click',()=>{
      this.exporter.captureHD(2048);
    });
  }
}
