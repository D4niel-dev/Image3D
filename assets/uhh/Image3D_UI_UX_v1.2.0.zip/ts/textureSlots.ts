export class TextureUI {
  constructor(private materialManager:any){ this.init(); }
  init(){
    document.querySelectorAll('.texture-slot').forEach(el=>{
      const input = el.querySelector('input') as HTMLInputElement;
      input.addEventListener('change',()=>{
        const f=input.files?.[0];
        if(f) this.materialManager.loadTexture(el.dataset.slot,f);
      });
    });
  }
}
